% This function runs slow, further modifications on it would be released in the furture.
function label=ICFFCM(IMG,C,U,a,sigma,alpha)
tic
[height,width]=size(IMG);
N=height*width;
coor=zeros(height,width,2); 
for i=1 : height
    for j= 1 : width
        coor(i,j,1)=i;
        coor(i,j,2)=j;
    end
end
coor_data=reshape(coor,[],2);
coor_x_data=coor_data(:,1);
coor_y_data=coor_data(:,2);

X=reshape(IMG,[],1);

v=sum(X)/N;
d=abs(X-v);
d_avg=sum(d)/N;
h=abs(d-d_avg);
H=sum(h)/N;
toc
RHO=zeros(C,N); 
t=0;
L=zeros(C,N);
L3d=reshape(L',height,width,C);
while(t<100)   
    Uxing=1-(1-U.^a).^(1/a);
    for k=1:N
    Wg=exp(-((X-X(k))./H).^2);
    Wx=abs(coor_x_data-coor_x_data(k));
    Wy=abs(coor_y_data-coor_y_data(k));
    Ws=exp(-(sqrt(Wx.^2+Wy.^2))./sigma);
    W=Wg.*Ws;
    RHO(:,k)=((Uxing.^2)*W)./sum((Uxing.^2),2);
    end
    U3d=reshape(Uxing',height,width,C);
    RHO3d=reshape(RHO',height,width,C);
    for i=1:C
        L3d(:,:,i)=imfilter(((U3d(:,:,i).^2).*(RHO3d(:,:,i).^(-2))),[alpha/8 alpha/8 alpha/8;alpha/8 0 alpha/8;alpha/8 alpha/8 alpha/8]);
    end
    L_d=reshape(L3d,N,C);
    L=L_d';
    Ufenzi=(RHO.^(-2)+L).^(-1);
    CSUfenzi=sum(Ufenzi);
    Unew=(Ufenzi)./CSUfenzi(ones(C,1),:);
   
epsilon=max(max(abs(Unew-U)));
if epsilon<0.001 
    break;
else
    U=Unew;
end
    t=t+1;
end
[~,label]=max(Unew);
end